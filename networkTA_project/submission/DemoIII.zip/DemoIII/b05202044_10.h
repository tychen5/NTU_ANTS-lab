#ifndef SERVER_DEF_H_
#define SERVER_DEF_H_

#define THREAD 32
#define QUEUE 256

#endif