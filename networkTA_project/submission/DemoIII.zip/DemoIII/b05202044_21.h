#ifndef UTIL_H
#define UTIL_H

#include <string.h>
#include <stdio.h>
#include "def.h"

size_t my_read(char *buf);

#endif