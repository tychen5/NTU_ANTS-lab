#ifndef COMMON_HEADER
#define COMMON_HEADER

#include <stdio.h>
#define BUF_SIZE 100

struct message_header{
    int message_type;
    int message_length;
};

#endif

#include <string>
using namespace std;

 
