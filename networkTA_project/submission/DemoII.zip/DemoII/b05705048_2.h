#ifndef _SERVER_COMM_H_
#define _SERVER_COMM_H_

#include <stdio.h>

void server_run(int connfd, void *, void *);

#endif // _SERVER_COMM_H_
